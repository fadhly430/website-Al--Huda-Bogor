<!DOCTYPE html>
<html lang="id-ID" >
<head>
<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '261083737929935');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=261083737929935&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

  <title>Yayasan Islam Al Huda Bogor-Indonesia</title>

  <link rel="stylesheet" href="//fonts.googleapis.com/earlyaccess/droidarabicnaskh.css" type="text/css">
  <link rel="stylesheet" href="css/main.css" type="text/css">
  <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="vendor/flexslider/flexslider.css" type="text/css">

  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/main.js"></script>
  <script type="text/javascript" src="vendor/flexslider/jquery.flexslider-min.js"></script>
</head>
<body class="ltr">
<!-- Wrap all page content here -->
<div id="wrap">
  <div class="site-header">
    <div class="container">
     <ul class="lang-switch block-group">
        <li class="block -ar ">
          <a href="?lang=ar"><i class="icon"></i><span>العربية</span></a>
        </li>
        <li class="block -id -active">
          <a href="?lang=id-ID"><i class="icon"></i><span>INDONESIA</span></a>
        </li>
      </ul>
      

      <a class="home-link" href="index.php" title="Yayasan Islam Al Huda Bogor-Indonesia" rel="home">
        <img class="logo u-cb" src="img/logo.jpg" alt="">
      </a>

      <ul class="menu-toggles block-group u-tb u-tu">
        <li class="menu-toggle menu-toggle--donate block"><a href="" class="button" data-menu="donate">Donasi<i class="fa fa-caret-down"></i></a></li>
        <li class="menu-toggle menu-toggle--primary block"><a href="" class="button -alt" data-menu="primary">Menu<i class="fa fa-caret-down"></i></a></li>
      </ul>

      <ul class="menu menu--donate u-tb u-tu">
        <li><a href="#">Menu #1</a></li>
        <li><a href="#">Menu #1</a></li>
      </ul>

      <ul class="menu menu--primary u-tb u-tu">
        <li class="">
          <a href="index.php">Beranda</a>
        </li>
        <li class="-active">
          <a href="page-profil.php">Profil</a>
        </li>
        <li class="">
          <a href="page-projek.php">Projek</a>
        </li>
        <li><a href="page-proposal.php">Proposal</a></li>
        <li><a href="archive.php">Kegiatan</a></li>
        <li><a href="archive.php">Galeri</a></li>
        <li><a href="archive.php">Artikel</a></li>
      </ul>
    </div>
  </div> <!-- /.site-header -->

  <div class="site-content">
    <div class="container"><div class="container__inner">
<p class="breadcrumbs">
  <span prefix="v: http://rdf.data-vocabulary.org/#">
    <span typeof="v:Breadcrumb"><a href="index.php" rel="v:url" property="v:title">Beranda</a></span> » <span typeof="v:Breadcrumb"><span class="breadcrumb_last" property="v:title">Profil</span></span>
  </span>
</p>

<div class="single single--page">
  <h1 class="page__title">Profil</h1>

  <div class="page__content">
    <p class="intro">Yayasan Islam Al Huda Bogor-Indonesia adalah salah satu lembaga yang konsentrasi bergerak dalam Program Dakwah, Pendidikan, dan Sosial.</p>

    <div class="u-hsep"></div>
    <div class="tabs block-group">
      <ul class="tabs__controls block">
        <li rel="tab-sejarah">Sejarah<i class="fa fa-arrow-right"></i></li>
        <li rel="tab-visi-misi">Visi dan Misi<i class="fa fa-arrow-right"></i></li>
        <li rel="tab-departemen">Departemen<i class="fa fa-arrow-right"></i></li>
        <li rel="tab-struktur">Struktur<i class="fa fa-arrow-right"></i></li>
      </ul>

      <div class="tabs__pages block">
        <p class="tabs__page--heading" rel="tab-sejarah">Sejarah</p>
        <div id="tab-sejarah" class="tabs__page">
          <h2 class="tabs__page--title">Sejarah</h2>
          <p>Aenean sed sem augue. Praesent feugiat eros in leo lacinia sollicitudin. Donec id dui purus. Nunc massa nulla, facilisis quis augue vitae, ornare rutrum nibh. Phasellus et turpis pulvinar, pulvinar urna at, condimentum lectus.</p>
<p>Nullam non metus odio. Fusce viverra quam adipiscing orci aliquet pellentesque.</p>
<p>Proin et ultricies dolor. Praesent ut pretium nisi. Proin et ultricies dolor.</p>
<p><a href='/'>Aliquam</a> commodo lectus mauris, id pretium neque malesuada sit amet. Praesent ut pretium nisi. Praesent feugiat eros in leo lacinia sollicitudin. Ut mattis arcu ut risus pellentesque porta. Morbi dolor sem, commodo ut metus sit amet, pulvinar ultrices sem. Maecenas placerat orci non lectus vestibulum convallis. Aliquam erat volutpat.</p>
<p><img class='a-img-responsive -left' src='placeholder/?r=307-393-post1695280869'></p>
<p>Praesent non nunc lacinia, mattis elit ac, commodo sem. Maecenas mollis tortor nisi, sit amet ultrices nisl viverra sit amet. Fusce at faucibus ipsum. Nunc lobortis sollicitudin nulla, non semper lectus eleifend sed. Phasellus congue aliquam sem, quis lobortis mi hendrerit vel.</p>
<p>Phasellus et turpis pulvinar, pulvinar urna at, condimentum lectus. Morbi lobortis nibh congue vehicula ornare. Nulla iaculis lacus in <a href='/'>ligula sollicitudin tincidunt</a>. Nullam ut interdum metus, a posuere velit. Nunc massa nulla, facilisis quis augue vitae, ornare rutrum nibh.</p>
<ul>
<li>Nullam consectetur, ligula at rutrum volutpat, quam elit tincidunt diam, a cursus felis nisl id augue</li>
<li>Sed hendrerit, turpis ac consequat commodo, erat libero ultricies risus, id posuere <a href='/'>lectus tellus</a> vel neque</li>
<li>Sed <del>vulputate diam vitae velit</del> <ins>pharetra tempus</ins></li>
<li>Quisque ullamcorper aliquet ante, sit amet molestie magna auctor nec</li>
</ul>
<p><a href='/'>Quisque interdum</a>, metus ut posuere aliquet, elit arcu lacinia ipsum, sit <a href='/'>amet eleifend lacus</a> quam id felis. Fusce viverra quam adipiscing orci aliquet pellentesque.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nam luctus dapibus sagittis.</p>
<p>Donec ullamcorper volutpat lectus a egestas. Nunc lobortis sollicitudin nulla, non semper lectus eleifend sed.</p>
<p>Donec ullamcorper volutpat lectus a egestas. Sed ultrices dictum velit ut elementum. Sed <del>vulputate diam vitae velit</del> <ins>pharetra tempus</ins>. Nam luctus dapibus sagittis. Nunc massa nulla, facilisis quis augue vitae, ornare rutrum nibh.</p>
<p><img class='a-img-responsive ' src='placeholder/?r=346-459-post1814069823'></p>
<p>Aliquam <a href='/'>sodales blandit felis</a>, vitae imperdiet nisl. Sed hendrerit, turpis ac consequat commodo, erat libero ultricies risus, id posuere <a href='/'>lectus tellus</a> vel neque. Proin id est eu <u>libero fermentum</u> blandit et a metus. Nulla iaculis lacus in <a href='/'>ligula sollicitudin tincidunt</a>. Aliquam <a href='/'>sodales blandit felis</a>, vitae imperdiet nisl.</p>
<p>Quisque dignissim sapien nec pretium adipiscing. Phasellus <code>semper tortor quis eleifend</code> tristique. Sed <del>vulputate diam vitae velit</del> <ins>pharetra tempus</ins>. Morbi lobortis nibh congue vehicula ornare. Phasellus <code>semper tortor quis eleifend</code> tristique. Morbi lobortis nibh congue vehicula ornare.</p>
<p>Fusce viverra quam adipiscing orci aliquet pellentesque. Vestibulum id cursus magna. Quisque dignissim sapien nec pretium adipiscing.</p>
        </div><!-- /.tabs__page -->

        <p class="tabs__page--heading" rel="tab-visi-misi">Visi dan Misi</p>
        <div id="tab-visi-misi" class="tabs__page">
          <h2 class="tabs__page--title">Visi dan Misi</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ac odio magna. Mauris tempus, elit ut <a href='/'>fringilla auctor</a>, mauris tellus pellentesque dui, ut blandit turpis nulla vel quam.</p>
<p><img class='a-img-responsive -left' src='placeholder/?r=425-345-post1504811737'></p>
<p>Vestibulum convallis pharetra mauris sed hendrerit. Fusce viverra quam adipiscing orci aliquet pellentesque. Proin et ultricies dolor. Sed ultrices dictum velit ut elementum.</p>
<p>Ut non erat dui. Phasellus et turpis pulvinar, pulvinar urna at, condimentum lectus. Proin et ultricies dolor. Praesent ut pretium nisi. Morbi ac odio magna.</p>
<p><img class='a-img-responsive -left' src='placeholder/?r=410-546-post781335660'></p>
<ol>
<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
<li>Nullam non metus odio</li>
<li>Vestibulum id cursus magna</li>
<li>Quisque quis tortor sit amet libero <em>dignissim cursus pharetra</em> ut lorem</li>
<li>Sed ultrices dictum velit ut elementum</li>
</ol>
<ul>
<li>Phasellus <code>semper tortor quis eleifend</code> tristique</li>
<li>Praesent ut pretium nisi</li>
</ul>
<p><a href='/'>Aliquam</a> commodo lectus mauris, id pretium neque malesuada sit amet. Vestibulum id cursus magna. Vestibulum convallis pharetra mauris sed hendrerit.</p>
<p>Lorem ipsum <del>dolor sit amet</del> <ins>placerat</ins>, consectetur adipiscing elit. Donec ullamcorper volutpat lectus a egestas. Quisque ullamcorper aliquet ante, sit amet molestie magna auctor nec. Ut ullamcorper eget orci id tincidunt. Curabitur tempor adipiscing tempor.</p>
<p>Aenean sed sem augue. Nullam non metus odio. Nam vitae <strong>nisi auctor</strong>, mollis urna ut, tempor mauris. Proin id est eu <u>libero fermentum</u> blandit et a metus. Nullam ut interdum metus, a posuere velit. Quisque quis tortor sit amet libero <em>dignissim cursus pharetra</em> ut lorem.</p>
<p>Donec ullamcorper volutpat lectus a egestas. Donec id dui purus. Praesent non nunc lacinia, mattis elit ac, commodo sem.</p>
<p>Phasellus congue aliquam sem, quis lobortis mi hendrerit vel. Praesent feugiat eros in leo lacinia sollicitudin. Aliquam non <em>dignissim odio, id</em> sagittis enim. Donec cursus nisi nisl, a vehicula velit adipiscing id.</p>
<p>Phasellus congue aliquam sem, quis lobortis mi hendrerit vel. Sed <del>vulputate diam vitae velit</del> <ins>pharetra tempus</ins>. Praesent ut pretium nisi.</p>
<p>Phasellus et turpis pulvinar, pulvinar urna at, condimentum lectus. In placerat, purus quis fringilla tempor, eros mi dapibus justo, ut pellentesque justo ipsum nec felis. Fusce viverra quam adipiscing orci aliquet pellentesque. Nunc massa nulla, facilisis quis augue vitae, ornare rutrum nibh.</p>
<ol>
<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
<li>Pellentesque molestie <u>imperdiet nulla</u> id ultrices</li>
<li>Mauris facilisis <strong>odio consectetur enim rhoncus, sed ultrices dolor aliquam</strong></li>
<li>Aliquam non <em>dignissim odio, id</em> sagittis enim</li>
</ol>
<ol>
<li>Nunc lobortis sollicitudin nulla, non semper lectus eleifend sed</li>
<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
<li>Nunc metus quam, volutpat ut vestibulum vel, rhoncus et purus</li>
<li>Cras eget ipsum non tellus consectetur condimentum</li>
</ol>
<ul>
<li>Vestibulum dictum leo vitae nulla fermentum ultrices</li>
<li>Sed <del>vulputate diam vitae velit</del> <ins>pharetra tempus</ins></li>
<li>Pellentesque euismod semper ornare</li>
<li>Sed ultrices dictum velit ut elementum</li>
</ul>
        </div><!-- /.tabs__page -->

        <p class="tabs__page--heading" rel="tab-departemen">Departemen</p>
        <div id="tab-departemen" class="tabs__page">
          <h2 class="tabs__page--title">Departemen</h2>
          <p>Vestibulum id cursus magna. Morbi ac odio magna. Quisque quis tortor sit amet libero <em>dignissim cursus pharetra</em> ut lorem.</p>
<p>Quisque quis tortor sit amet libero <em>dignissim cursus pharetra</em> ut lorem. Vestibulum id cursus magna.</p>
<p><img class='a-img-responsive -center' src='placeholder/?r=843-202-post2066366957'></p>
<p>Vestibulum id cursus magna. Maecenas placerat orci non lectus vestibulum convallis. Donec pellentesque sit amet nibh sed accumsan. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
<p><img class='a-img-responsive -right' src='placeholder/?r=373-325-post1189840646'></p>
<p>Sed <del>vulputate diam vitae velit</del> <ins>pharetra tempus</ins>. Nulla iaculis lacus in <a href='/'>ligula sollicitudin tincidunt</a>. In placerat, purus quis fringilla tempor, eros mi dapibus justo, ut pellentesque justo ipsum nec felis. Proin et ultricies dolor. Quisque quis tortor sit amet libero <em>dignissim cursus pharetra</em> ut lorem. Mauris tempus, elit ut <a href='/'>fringilla auctor</a>, mauris tellus pellentesque dui, ut blandit turpis nulla vel quam.</p>
<p>Fusce viverra quam adipiscing orci aliquet pellentesque. Maecenas mollis tortor nisi, sit amet ultrices nisl viverra sit amet. Morbi ac odio magna.</p>
<p>Praesent feugiat eros in leo lacinia sollicitudin. Curabitur tempor adipiscing tempor. Mauris facilisis <strong>odio consectetur enim rhoncus, sed ultrices dolor aliquam</strong>. Sed hendrerit, turpis ac consequat commodo, erat libero ultricies risus, id posuere <a href='/'>lectus tellus</a> vel neque. Ut ullamcorper eget orci id tincidunt. Praesent ac ipsum at ipsum consectetur ornare vitae quis nisi. Phasellus et turpis pulvinar, pulvinar urna at, condimentum lectus.</p>
<p>Lorem ipsum <del>dolor sit amet</del> <ins>placerat</ins>, consectetur adipiscing elit. Sed <del>vulputate diam vitae velit</del> <ins>pharetra tempus</ins>.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur tempor adipiscing tempor.</p>
<blockquote><p>Duis facilisis tempus turpis at sollicitudin. Pellentesque molestie <u>imperdiet nulla</u> id ultrices. Pellentesque euismod semper ornare. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent non nunc lacinia, mattis elit ac, commodo sem.</p></blockquote>
<p>Vestibulum convallis pharetra mauris sed hendrerit. Pellentesque euismod semper ornare. Donec cursus nisi nisl, a vehicula velit adipiscing id. Morbi lobortis nibh congue vehicula ornare. Duis facilisis tempus turpis at sollicitudin.</p>
<p>Interdum et malesuada fames ac ante ipsum primis in faucibus. Nullam consectetur, ligula at rutrum volutpat, quam elit tincidunt diam, a cursus felis nisl id augue. Nullam consectetur, ligula at rutrum volutpat, quam elit tincidunt diam, a cursus felis nisl id augue.</p>
<blockquote><p>Proin et ultricies dolor. Nullam non metus odio. Proin dolor lorem, pharetra <code>sit amet</code> nunc a, suscipit bibendum velit. Maecenas placerat orci non lectus vestibulum convallis. Nullam non metus odio.</p></blockquote>
<p>Nullam non metus odio. Quisque ullamcorper aliquet ante, sit amet molestie magna auctor nec. Donec cursus nisi nisl, a vehicula velit adipiscing id. Nullam consectetur, ligula at rutrum volutpat, quam elit tincidunt diam, a cursus felis nisl id augue. Proin et ultricies dolor. Quisque ullamcorper aliquet ante, sit amet molestie magna auctor nec.</p>
<p>Suspendisse blandit risus vel sem placerat, nec sagittis magna auctor. Quisque dignissim sapien nec pretium adipiscing.</p>
<ul>
<li>Praesent ut pretium nisi</li>
<li>Ut mattis arcu ut risus pellentesque porta</li>
</ul>
<ul>
<li>In placerat, purus quis fringilla tempor, eros mi dapibus justo, ut pellentesque justo ipsum nec felis</li>
<li>Interdum et malesuada fames ac ante ipsum primis in faucibus</li>
<li>In placerat, purus quis fringilla tempor, eros mi dapibus justo, ut pellentesque justo ipsum nec felis</li>
<li>Pellentesque molestie <u>imperdiet nulla</u> id ultrices</li>
<li>Quisque quis tortor sit amet libero <em>dignissim cursus pharetra</em> ut lorem</li>
</ul>
        </div><!-- /.tabs__page -->

        <p class="tabs__page--heading" rel="tab-struktur">Struktur</p>
        <div id="tab-struktur" class="tabs__page">
          <h2 class="tabs__page--title">Struktur</h2>
          <p>Nunc lobortis sollicitudin nulla, non semper lectus eleifend sed. Nunc metus quam, volutpat ut vestibulum vel, rhoncus et purus. Donec cursus nisi nisl, a vehicula velit adipiscing id. Curabitur tempor adipiscing tempor. In placerat, purus quis fringilla tempor, eros mi dapibus justo, ut pellentesque justo ipsum nec felis. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
<p>Nunc lobortis sollicitudin nulla, non semper lectus eleifend sed. Praesent ut pretium nisi. Nunc metus quam, volutpat ut vestibulum vel, rhoncus et purus. Vestibulum id cursus magna. Ut mattis arcu ut risus pellentesque porta. Ut non erat dui. Cras eget ipsum non tellus consectetur condimentum.</p>
<p>Vestibulum convallis pharetra mauris sed hendrerit. Nunc metus quam, volutpat ut vestibulum vel, rhoncus et purus. Phasellus <code>semper tortor quis eleifend</code> tristique. Donec id dui purus. Morbi ac odio magna. Aenean sed sem augue.</p>
<p><img class='a-img-responsive -right' src='placeholder/?r=551-486-post1113078676'></p>
<p>Aenean sed sem augue. Curabitur tempor adipiscing tempor. Phasellus sapien massa, vulputate ut tellus accumsan, tempor rutrum augue.</p>
<p>Nullam non metus odio. Phasellus congue aliquam sem, quis lobortis mi hendrerit vel. Donec pellentesque sit amet nibh sed accumsan. Praesent ut pretium nisi.</p>
<p>Mauris facilisis <strong>odio consectetur enim rhoncus, sed ultrices dolor aliquam</strong>. Mauris facilisis <strong>odio consectetur enim rhoncus, sed ultrices dolor aliquam</strong>. Donec ullamcorper volutpat lectus a egestas. Curabitur pellentesque vel orci sed sagittis. Praesent ac ipsum at ipsum consectetur ornare vitae quis nisi. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
<p><a href='/'>Aliquam</a> commodo lectus mauris, id pretium neque malesuada sit amet. Maecenas mollis tortor nisi, sit amet ultrices nisl viverra sit amet. Nunc metus quam, volutpat ut vestibulum vel, rhoncus et purus. Curabitur pellentesque vel orci sed sagittis. Quisque quis tortor sit amet libero <em>dignissim cursus pharetra</em> ut lorem. In placerat, purus quis fringilla tempor, eros mi dapibus justo, ut pellentesque justo ipsum nec felis. Fusce viverra quam adipiscing orci aliquet pellentesque.</p>
<blockquote><p>Ut non erat dui. Vestibulum dictum leo vitae nulla fermentum ultrices. Curabitur pellentesque vel orci sed sagittis. Nullam non metus odio. Nunc massa nulla, facilisis quis augue vitae, ornare rutrum nibh. Sed <del>vulputate diam vitae velit</del> <ins>pharetra tempus</ins>. Proin et ultricies dolor.</p></blockquote>
<ol>
<li>Curabitur pellentesque vel orci sed sagittis</li>
<li>Nullam ut interdum metus, a posuere velit</li>
</ol>
<p>Nulla iaculis lacus in <a href='/'>ligula sollicitudin tincidunt</a>. Nullam ut interdum metus, a posuere velit. Nunc massa nulla, facilisis quis augue vitae, ornare rutrum nibh. Maecenas mollis tortor nisi, sit amet ultrices nisl viverra sit amet. Praesent ut pretium nisi. Suspendisse blandit risus vel sem placerat, nec sagittis magna auctor. Phasellus <code>semper tortor quis eleifend</code> tristique.</p>
<p>Quisque quis tortor sit amet libero <em>dignissim cursus pharetra</em> ut lorem. Nunc massa nulla, facilisis quis augue vitae, ornare rutrum nibh. Phasellus <code>semper tortor quis eleifend</code> tristique. <a href='/'>Quisque interdum</a>, metus ut posuere aliquet, elit arcu lacinia ipsum, sit <a href='/'>amet eleifend lacus</a> quam id felis. <a href='/'>Aliquam</a> commodo lectus mauris, id pretium neque malesuada sit amet. <a href='/'>Quisque interdum</a>, metus ut posuere aliquet, elit arcu lacinia ipsum, sit <a href='/'>amet eleifend lacus</a> quam id felis. Phasellus sapien massa, vulputate ut tellus accumsan, tempor rutrum augue.</p>
<p>Donec ullamcorper volutpat lectus a egestas. Nam vitae <strong>nisi auctor</strong>, mollis urna ut, tempor mauris.</p>
<blockquote><p>Vestibulum dictum leo vitae nulla fermentum ultrices. Mauris tempus, elit ut <a href='/'>fringilla auctor</a>, mauris tellus pellentesque dui, ut blandit turpis nulla vel quam. Suspendisse blandit risus vel sem placerat, nec sagittis magna auctor. Ut non erat dui. Curabitur tempor adipiscing tempor. Sed <del>vulputate diam vitae velit</del> <ins>pharetra tempus</ins>.</p></blockquote>
<p>Aliquam erat volutpat. Nam luctus dapibus sagittis. Morbi lobortis nibh congue vehicula ornare.</p>
<ul>
<li>Pellentesque euismod semper ornare</li>
<li>Vestibulum convallis pharetra mauris sed hendrerit</li>
</ul>
        </div><!-- /.tabs__page -->
      </div>
    </div>
  </div>
</div>

    </div></div>
  </div> <!-- /.site-content -->

  <div class="site-footer">
    <div class="site-footer__top">
      <div class="container"><div class="container__inner">
        <div class="block-group">
          <p class="copyright block">Copyright &copy; 2019 Yayasan Islam Al Huda Bogor-Indonesia</p>

          <ul class="social-links block">
            <li><a href="http://www.facebook.com/" class="facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="http://twitter.com/" class="twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a href="feed" class="feed"><i class="fa fa-rss"></i></a></li>
          </ul>

        
        </div></div>
      </div>
    </div>

    <div class="site-footer__bottom">
      <div class="container">
        <div class="block-group">
          <div class="block -md-1-3">
            <h4 class="block__title">Tentang Kami</h4>

            <p>Yayasan Islam Al Huda Bogor-Indonesia adalah salah satu lembaga yang konsentrasi bergerak dalam Program Dakwah, Pendidikan, dan Sosial.</p>

            <p><a href="#" class="button">Selengkapnya</a></p>
          </div>
          <div class="block -sm-1-2 -md-1-3">
            <h4 class="block__title">Salurkan Donasi Anda</h4>

            <ul class="list-bullet-square">
              <li>Bank Syariah Mandiri (BSM) <br>
              No. Rekening: 1234.5678.90 <br>
              a/n Yayasan Islam Al Huda Bogor</li>
            </ul>

            <p><a href="#" class="button">Konfirmasi Donasi</a></p>
          </div>
          <div class="block -sm-1-2 -md-1-3">
            <h4 class="block__title">Kontak Kami</h4>

            <div class="vcard">
              <p class="org">Yayasan Islam Al Huda Bogor-Indonesia</p>
              <p class="adr">
                <span class="street-address">Jalan Raya Cimanglid Gg. Purnama RT/RW 05/01 PO. Box: 01 Ciomas</span>,
                <span class="locality">Bogor</span>,
                <span class="postal-code">16610</span>,
                <span class="region">Jawa Barat</span>,
                <span class="country-name">Indonesia</span>
              </p>
              <p class="tel">Telp. <span class="value">+62 251 487512</span></p>
              <p class="tel"><span class="type">Fax</span>. <span class="value">+62 251 487512</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> <!-- /#wrap -->

<script type="text/javascript">
  WebFontConfig = {
    google: {
      families: [ 'Roboto:900,900italic,400italic,700italic,700,400:latin', 'Halant::latin' ]
    }
  };

  (function() {
    var wf = document.createElement('script');
    wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
        '://ajax.googleapis.com/ajax/libs/webfont/1.5.0/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(wf, s);
  })();
</script>
</body>
</html>