<!DOCTYPE html>
<html lang="id-ID" >
<head>
<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '261083737929935');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=261083737929935&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

  <title>Yayasan Islam Al Huda Bogor-Indonesia</title>

  <link rel="stylesheet" href="//fonts.googleapis.com/earlyaccess/droidarabicnaskh.css" type="text/css">
  <link rel="stylesheet" href="css/main.css" type="text/css">
  <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="vendor/flexslider/flexslider.css" type="text/css">

  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/main.js"></script>
  <script type="text/javascript" src="vendor/flexslider/jquery.flexslider-min.js"></script>
</head>
<body class="ltr">
<!-- Wrap all page content here -->
<div id="wrap">
  <div class="site-header">
    <div class="container">
     <ul class="lang-switch block-group">
        <li class="block -ar ">
          <a href="?lang=ar"><i class="icon"></i><span>العربية</span></a>
        </li>
        <li class="block -id -active">
          <a href="?lang=id-ID"><i class="icon"></i><span>INDONESIA</span></a>
        </li>
      </ul>
      

      <a class="home-link" href="index.php" title="Yayasan Islam Al Huda Bogor-Indonesia" rel="home">
        <img class="logo u-cb" src="img/logo.jpg" alt="">
      </a>

      <ul class="menu-toggles block-group u-tb u-tu">
        <li class="menu-toggle menu-toggle--donate block"><a href="" class="button" data-menu="donate">Donasi<i class="fa fa-caret-down"></i></a></li>
        <li class="menu-toggle menu-toggle--primary block"><a href="" class="button -alt" data-menu="primary">Menu<i class="fa fa-caret-down"></i></a></li>
      </ul>

      <ul class="menu menu--donate u-tb u-tu">
        <li><a href="#">Menu #1</a></li>
        <li><a href="#">Menu #1</a></li>
      </ul>

      <ul class="menu menu--primary u-tb u-tu">
        <li class="">
          <a href="index.php">Beranda</a>
        </li>
        <li class="">
          <a href="page-profil.php">Profil</a>
        </li>
        <li class="">
          <a href="page-projek.php">Projek</a>
        </li>
        <li><a href="page-proposal.php">Proposal</a></li>
        <li><a href="archive.php">Kegiatan</a></li>
        <li><a href="archive.php">Galeri</a></li>
        <li><a href="archive.php">Artikel</a></li>
      </ul>
    </div>
  </div> <!-- /.site-header -->

  <div class="site-content">
    <div class="container"><div class="container__inner">

<div class="block-group -padded">
  <div class="block -md-2-3">
    <p class="breadcrumbs">
      <span prefix="v: http://rdf.data-vocabulary.org/#">
        <span typeof="v:Breadcrumb"><a href="index.php" rel="v:url" property="v:title">Beranda</a></span> » <span typeof="v:Breadcrumb"><a href="archive.php" rel="v:url" property="v:title">Kegiatan</a></span> » <span typeof="v:Breadcrumb"><span class="breadcrumb_last" property="v:title">Bibendum Nam Tempor Rutrum</span></span>
      </span>
    </p>

    <div class="single single--post">
      <h1 class="post__title">Bibendum Nam Tempor Rutrum</h1>

      <p class="post__meta">
        Dipublikasikan pada:        <time class="published" datetime="2019-12-22T11:13:59+07:00">22 December 2019</time>
        |
        Kategori:        <a href="archive.php">Kegiatan</a>
      </p>
      <div class="post__content">
        <p>Praesent ac ipsum at ipsum consectetur ornare vitae quis nisi. Morbi ac odio magna. Sed <del>vulputate diam vitae velit</del> <ins>pharetra tempus</ins>. Aenean sed sem augue.</p>
<p>Praesent ac ipsum at ipsum consectetur ornare vitae quis nisi. Proin id est eu <u>libero fermentum</u> blandit et a metus. Nullam consectetur, ligula at rutrum volutpat, quam elit tincidunt diam, a cursus felis nisl id augue.</p>
<p><img class='a-img-responsive -center' src='placeholder/?r=614-413-post854818592'></p>
<p>Nullam consectetur, ligula at rutrum volutpat, quam elit tincidunt diam, a cursus felis nisl id augue. Nullam consectetur, ligula at rutrum volutpat, quam elit tincidunt diam, a cursus felis nisl id augue. Maecenas mollis tortor nisi, sit amet ultrices nisl viverra sit amet. Pellentesque euismod semper ornare. Nullam ut interdum metus, a posuere velit. Proin et ultricies dolor.</p>
<ul>
<li>Nullam ut interdum metus, a posuere velit</li>
<li>Curabitur pellentesque vel orci sed sagittis</li>
</ul>
<p>Proin dolor lorem, pharetra <code>sit amet</code> nunc a, suscipit bibendum velit. Phasellus sapien massa, vulputate ut tellus accumsan, tempor rutrum augue. Nunc massa nulla, facilisis quis augue vitae, ornare rutrum nibh. Aliquam erat volutpat. Aliquam erat volutpat. Aliquam non <em>dignissim odio, id</em> sagittis enim.</p>
<blockquote><p>Nullam consectetur, ligula at rutrum volutpat, quam elit tincidunt diam, a cursus felis nisl id augue. Quisque quis tortor sit amet libero <em>dignissim cursus pharetra</em> ut lorem. Sed <del>vulputate diam vitae velit</del> <ins>pharetra tempus</ins>. Phasellus congue aliquam sem, quis lobortis mi hendrerit vel. Sed hendrerit, turpis ac consequat commodo, erat libero ultricies risus, id posuere <a href='/'>lectus tellus</a> vel neque. Pellentesque molestie <u>imperdiet nulla</u> id ultrices.</p></blockquote>
<p><img class='a-img-responsive -right' src='placeholder/?r=759-347-post690246531'></p>
<p>Proin et ultricies dolor. Nam luctus dapibus sagittis. <a href='/'>Quisque interdum</a>, metus ut posuere aliquet, elit arcu lacinia ipsum, sit <a href='/'>amet eleifend lacus</a> quam id felis. Maecenas placerat orci non lectus vestibulum convallis.</p>
<p><a href='/'>Aliquam</a> commodo lectus mauris, id pretium neque malesuada sit amet. In placerat, purus quis fringilla tempor, eros mi dapibus justo, ut pellentesque justo ipsum nec felis.</p>
<p>Curabitur tempor adipiscing tempor. Nam vitae <strong>nisi auctor</strong>, mollis urna ut, tempor mauris. Pellentesque molestie <u>imperdiet nulla</u> id ultrices. Suspendisse blandit risus vel sem placerat, nec sagittis magna auctor. Lorem ipsum <del>dolor sit amet</del> <ins>placerat</ins>, consectetur adipiscing elit. <a href='/'>Aliquam</a> commodo lectus mauris, id pretium neque malesuada sit amet.</p>
<p>Duis facilisis tempus turpis at sollicitudin. Nam luctus dapibus sagittis. Fusce at faucibus ipsum. Aliquam <a href='/'>sodales blandit felis</a>, vitae imperdiet nisl. Quisque quis tortor sit amet libero <em>dignissim cursus pharetra</em> ut lorem.</p>
<p>Vestibulum dictum leo vitae nulla fermentum ultrices. Fusce at faucibus ipsum. Fusce at faucibus ipsum. Aenean sed sem augue. Mauris tempus, elit ut <a href='/'>fringilla auctor</a>, mauris tellus pellentesque dui, ut blandit turpis nulla vel quam. Quisque quis tortor sit amet libero <em>dignissim cursus pharetra</em> ut lorem. Vestibulum convallis pharetra mauris sed hendrerit.</p>
<p>Aliquam <a href='/'>sodales blandit felis</a>, vitae imperdiet nisl. Donec pellentesque sit amet nibh sed accumsan.</p>
      </div>
    </div>
  </div>

  <div class="block -md-1-3">
    <div class="sidebar">
  <img src="placeholder/?r=300-250" alt="" class="a-img-responsive">

  <div class="u-hsep"></div>

  <div class="widget">
    <h4 class="widget__title">Tulisan Lainnya</h4>
    <ul class="list-simple">
      <li><a href="single.php">Iaculis Ut Bibendum In Tempor</a></li>
      <li><a href="single.php">Arcu Ac Lacinia Id In</a></li>
      <li><a href="single.php">Sed Bibendum Fringilla Elit</a></li>
    </ul>
  </div>
</div>  </div>
</div>

    </div></div>
  </div> <!-- /.site-content -->

  <div class="site-footer">
    <div class="site-footer__top">
      <div class="container"><div class="container__inner">
        <div class="block-group">
          <p class="copyright block">Copyright &copy; 2019 Yayasan Islam Al Huda Bogor-Indonesia</p>

          <ul class="social-links block">
            <li><a href="http://www.facebook.com/" class="facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="http://twitter.com/" class="twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a href="feed" class="feed"><i class="fa fa-rss"></i></a></li>
          </ul>

        
        </div></div>
      </div>
    </div>

    <div class="site-footer__bottom">
      <div class="container">
        <div class="block-group">
          <div class="block -md-1-3">
            <h4 class="block__title">Tentang Kami</h4>

            <p>Yayasan Islam Al Huda Bogor-Indonesia adalah salah satu lembaga yang konsentrasi bergerak dalam Program Dakwah, Pendidikan, dan Sosial.</p>

            <p><a href="#" class="button">Selengkapnya</a></p>
          </div>
          <div class="block -sm-1-2 -md-1-3">
            <h4 class="block__title">Salurkan Donasi Anda</h4>

            <ul class="list-bullet-square">
              <li>Bank Syariah Mandiri (BSM) <br>
              No. Rekening: 1234.5678.90 <br>
              a/n Yayasan Islam Al Huda Bogor</li>
            </ul>

            <p><a href="#" class="button">Konfirmasi Donasi</a></p>
          </div>
          <div class="block -sm-1-2 -md-1-3">
            <h4 class="block__title">Kontak Kami</h4>

            <div class="vcard">
              <p class="org">Yayasan Islam Al Huda Bogor-Indonesia</p>
              <p class="adr">
                <span class="street-address">Jalan Raya Cimanglid Gg. Purnama RT/RW 05/01 PO. Box: 01 Ciomas</span>,
                <span class="locality">Bogor</span>,
                <span class="postal-code">16610</span>,
                <span class="region">Jawa Barat</span>,
                <span class="country-name">Indonesia</span>
              </p>
              <p class="tel">Telp. <span class="value">+62 251 487512</span></p>
              <p class="tel"><span class="type">Fax</span>. <span class="value">+62 251 487512</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> <!-- /#wrap -->

<script type="text/javascript">
  WebFontConfig = {
    google: {
      families: [ 'Roboto:900,900italic,400italic,700italic,700,400:latin', 'Halant::latin' ]
    }
  };

  (function() {
    var wf = document.createElement('script');
    wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
        '://ajax.googleapis.com/ajax/libs/webfont/1.5.0/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(wf, s);
  })();
</script>
</body>
</html>