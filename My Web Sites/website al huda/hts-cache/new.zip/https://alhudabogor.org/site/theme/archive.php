<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '868540926673419');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=868540926673419&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

  <meta charset="UTF-8">
  <meta name="developer" content="alhudabogor.org">
  <title>404 Page</title>
  <meta name="description" content="">
  <meta name="generator" content="ProcessWire">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

  <link rel="apple-touch-icon" sizes="57x57" href="/site/theme/img/favicons/apple-touch-icon-57x57.png">
  <link rel="apple-touch-icon" sizes="60x60" href="/site/theme/img/favicons/apple-touch-icon-60x60.png">
  <link rel="apple-touch-icon" sizes="72x72" href="/site/theme/img/favicons/apple-touch-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="76x76" href="/site/theme/img/favicons/apple-touch-icon-76x76.png">
  <link rel="apple-touch-icon" sizes="114x114" href="/site/theme/img/favicons/apple-touch-icon-114x114.png">
  <link rel="icon" type="image/png" href="/site/theme/img/favicons/favicon-32x32.png" sizes="32x32">
  <link rel="icon" type="image/png" href="/site/theme/img/favicons/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/png" href="/site/theme/img/favicons/favicon-16x16.png" sizes="16x16">
  <link rel="manifest" href="/site/theme/img/favicons/manifest.json">
  <link rel="shortcut icon" href="/site/theme/img/favicons/favicon.ico">
  <meta name="msapplication-TileColor" content="#da532c">
  <meta name="msapplication-config" content="/site/theme/img/favicons/browserconfig.xml">
  <meta name="theme-color" content="#ffffff">

  <link rel="stylesheet" href="/site/assets/aiom/css_5b4f3341f91a552d87c7423c12553925.css">

  <link rel="stylesheet" href="//fonts.googleapis.com/earlyaccess/droidarabicnaskh.css" type="text/css" media="none" onload="if(media!='all')media='all'">
  <link rel="stylesheet" href="//fonts.googleapis.com/earlyaccess/droidarabickufi.css" type="text/css" media="none" onload="if(media!='all')media='all'">

  <style type="text/css">/* Custom CSS */
@media (min-width: 960px){
.site-content {
    background:#fff9b1;
}
}
.site-header {
}
.site-header .menu > li.-active > a, .site-header .menu > li:hover > a {
    background:#ffd723;
    color:black;
    border-radius:4px 4px 0 0;
}
.list-bullet-square > li:before {
    background:black;
}
.site-footer > .site-footer__top .block-group .block:nth-child(1n+2):before {
    background:black;
}
a.button, button, input[type=button] {
    background:#43251b;
    color:white;
}
a.button:hover, button:hover, input[type=button]:hover {
  background: #99543D;
}

.menu-toggle--donate .button {
    background:#ffd723;
    color:black;
}
.featured-projects .u-tac .button {
    background:#ffd723;
    color:black;
}
@media (min-width: 560px) {
.site-footer > .site-footer__top .block-group .block:first-child:after {
    background:black;
}
}

.latest-posts .latest-posts__title, .widget > .widget__title {
    border-bottom:3px solid #43251b;
}

a {
    color:black;
}

.pagination li.active a {
    background:#43251b;
}

@media (min-width: 960px) {
    #wrap:before {
        background:#fff9b2;
    }
}

.site-footer > .site-footer__bottom .block-group {
    background:white;
}</style>

  <script type="text/javascript">
    var themeUrl = '/site/theme/';
  </script>
</head>
<body class="rtl has-banner-float">
<!-- Wrap all page content here -->
<div id="wrap">
  <div class="site-header -float">
    <div class="container">
      	<!-- language switcher / navigation -->
	<ul class="lang-switch block-group">
		<li class="block -id"><a href="/http404/"><i class="icon"></i><span>Indonesia</a></span></li>	</ul>


      <h1 class="site-title"><a href="/ar/">
        الهدى</a></h1>

      <ul class="menu-toggles block-group u-tb u-tu">
        <li class="menu-toggle menu-toggle--primary block"><a href="" class="button -alt" data-menu="primary">
          النوافذ<i class="fa fa-caret-down"></i></a>
        </li>
        <li class="menu-toggle menu-toggle--donate block"><a href="/ar/donasi/" class="button">
          التبرع</a>
        </li>
        <li class="menu-toggle menu-toggle--search block"><a href="" class="button -alt" data-menu="search">
          بحث<i class="fa fa-search"></i></a>
        </li>
      </ul>

      <div class="menu menu--search">
        <form action="/ar/search/">
          <input type="search" value="" name="q" placeholder="البحث">
        </form>
      </div>

      <ul class="menu menu--primary u-tb u-tu">
        <li><a href='/ar/'>الرئيسية</a></li><li><a href='/ar/profil/'>حول المؤسسة</a></li><li><a href='/ar/projek/'>المشروع</a></li><li><a href='/ar/kegiatan/'>البرامج</a></li><li><a href='/ar/galeri/'>الصور</a></li><li><a href='/ar/blog/'>المقالات</a></li><li><a href='/ar/video/'>الفيديو</a></li><li><a href='/ar/faq/'>الأسئلة</a></li><li><a href='/ar/nasihat/'>Nasihat</a></li>      </ul>
    </div>
  </div>

  <div class="site-header">
    <div class="container">
      	<!-- language switcher / navigation -->
	<ul class="lang-switch block-group">
		<li class="block -id"><a href="/http404/"><i class="icon"></i><span>Indonesia</a></span></li>	</ul>


      <a class="home-link" href="/ar/" title="404 Page" rel="home">
        <img class="logo u-cb" src="/site/theme/img/logo.jpg" alt="">
      </a>

      <h1 class="site-title"><a href="/ar/">مؤسسة الهدى الاسلامية بوقور اندونيسيا</a></h1>

      <ul class="menu-toggles block-group u-tb u-tu">
        <li class="menu-toggle menu-toggle--primary block"><a href="" class="button -alt" data-menu="primary">
          النوافذ<i class="fa fa-caret-down"></i></a>
        </li>
        <li class="menu-toggle menu-toggle--donate block"><a href="/ar/donasi/" class="button">
          التبرع</a>
        </li>
        <li class="menu-toggle menu-toggle--search block"><a href="" class="button -alt" data-menu="search">
          بحث<i class="fa fa-search"></i></a>
        </li>
      </ul>

      <div class="menu menu--search">
        <form action="/ar/search/">
          <input type="search" value="" name="q" placeholder="البحث">
        </form>
      </div>

      <ul class="menu menu--donate u-tb u-tu">
        <li><a href='/ar/donasi/#info'>المعلومات</a></li><li><a href='/ar/donasi/#laporan'>التقرير</a></li><li><a href='/ar/donasi/#konfirmasi'>التأكيد</a></li><li><a href='/ar/donasi/#proposal-buka-puasa-bersama-ramadhan-1437h'>Proposal Buka Puasa Bersama Ramadhan 1439H - 2018 M</a></li>      </ul>

      <ul class="menu menu--primary u-tb u-tu">
        <li><a href='/ar/'>الرئيسية</a></li><li><a href='/ar/profil/'>حول المؤسسة</a></li><li><a href='/ar/projek/'>المشروع</a></li><li><a href='/ar/kegiatan/'>البرامج</a></li><li><a href='/ar/galeri/'>الصور</a></li><li><a href='/ar/blog/'>المقالات</a></li><li><a href='/ar/video/'>الفيديو</a></li><li><a href='/ar/faq/'>الأسئلة</a></li><li><a href='/ar/nasihat/'>Nasihat</a></li>      </ul>
    </div>
  </div> <!-- /.site-header -->

  <div class="site-content">
    <div class="container"><div class="container__inner">

            <div class="breadcrumbs">
        <span xmlns:v="http://rdf.data-vocabulary.org/#">
                    <span typeof="v:Breadcrumb">
            <a href="/ar/" rel="v:url" property="v:title">الرئيسية</a>
          </span> <i>/</i>
                  </span>
        <span class="current">404 Page</span>

      </div>
      
      
<div class="single single--page">
  <h1 class="page__title">404 Page</h1>

  <div class="page__content">
    
    
    
  </div>
</div>


    </div></div>
  </div> <!-- /.site-content -->

  <div class="site-footer">

    <div class="site-footer__top">
      <div class="container"><div class="container__inner">
        <div class="block-group">
          <div class="block -md-1-3">
            <h4 class="block__title">حول المؤسسة</h4>

            <p>مؤسسة الهدى الإسلامية بوغور الاندونيسية هي واحدة من المؤسسات العاملة في برنامج تركيز دعوة والتعليم، والاجتماعي</p>

            <p><a href="/ar/profil/" class="button">
              المزيد            </a></p>
          </div>
          <div class="block -sm-1-2 -md-1-3">
            <h4 class="block__title">توجيه تبرعاتكم</h4>

            <ul class="list-bullet-square">
              <li>رقم الحساب البنك<br />
No. Rek Mandiri Syari'ah<br />
5308 270 700 <br />
-------------------------<br />
No. Rek BNI Syari'ah<br />
02 3738 3536 <br />
نيابة عن مؤسسة الهدى الإسلامية</li>
            </ul>

            <p><a href="/ar/donasi/#konfirmasi" class="button">
              تأكيد التبرع            </a></p>
          </div>
          <div class="block -sm-1-2 -md-1-3">
            <h4 class="block__title">اتصل بنا</h4>

            <div class="vcard">
              <p class="org">مؤسسة الهدى الاسلامية بوقور اندونيسيا</p>
              <p class="adr">Jl. Raya Kapten Yusuf, Cimanglid Gg. Purnama RT 05/01 PO.Box 01 Ciomas, 16610, No. 61 Ds. Sukamantri, Kec. Tamansari, Kab. Bogor - Jawa Barat<br />
-------------------------<br />
الجوال: 4481 1685 0852 <br />
الهاتف: 512 8487 251 +62</p>
              <!-- <p class="adr">
                <span class="street-address">Jalan Raya Cimanglid Gg. Purnama RT/RW 05/01 PO. Box: 01 Ciomas</span>,
                <span class="locality">Bogor</span>,
                <span class="postal-code">16610</span>,
                <span class="region">Jawa Barat</span>,
                <span class="country-name">Indonesia</span>
              </p>
              <p class="tel">Telp. <span class="value">+62 251 487512</span></p>
              <p class="tel"><span class="type">Fax</span>. <span class="value">+62 251 487512</span></p> -->
            </div>
          </div>
        </div>
      </div></div><!-- /.container -->
    </div>

    <div class="site-footer__bottom">
      <div class="container"><div class="container__inner">
        <div class="block-group">
          <p class="copyright block">
            جميع الحقوق محفوظة &copy; 2019 مؤسسة الهدى الاسلامية بوقور اندونيسيا          </p>

          <ul class="social-links block">
            <li><a href="https://goo.gl/LhBZwm" class="kaskus"><img src="/site/theme/img/icon-kaskus.png"></a></li>
            <li><a href="https://www.facebook.com/yayasan.alhuda.bogor" class="facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="https://twitter.com/yayasanalhuda" class="twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UC7I4J_nzuaJwYzpB3pvFGXQ" class="youtube"><i class="fa fa-youtube"></i></a></li>
            <li><a href="/ar/feed/" class="feed"><i class="fa fa-rss"></i></a></li>
          </ul>
<!--
          <p class="developer block">
            Developed by            <a href="http://alhudabogor.org">
              alhudabogor            </a>
          </p>
          -->
        </div></div>
      </div>
    </div>


  </div>
</div> <!-- /#wrap -->

<div class="m-banner-float js-banner-float">
  <a class="banner" href="http://www.facebook.com/yayasan.alhuda.bogor">
    <img src="/site/assets/files/1291/float_banner-ar.0x60.png">
    <span class="close" href="#">x</span>
  </a>
</div>

<div class="m-live-chat">
  <a onclick="return !window.open(this.href, 'Livechat', 'width=500,height=500')"
    target="_blank" class="toggle" href="/chat/php/app.php?widget-mobile">
    <img src="/site/theme/img/live-chat.png">
  </a>
</div>

  <script src="/site/assets/aiom/js_48ea6bc9e2bca60e043f6639f04675a5.js"></script>


<script type='text/javascript'>
// current pageviews: 644
var counterjs = "/counter.js?id=27&r=" + Date.now();
document.write('<scr'+'ipt type="text/javascript" src="'+counterjs+'"></sc'+'ript>');
</script>

<script type="text/javascript">
  WebFontConfig = {
    google: {
      families: [ 'Roboto:900,900italic,400italic,700italic,700,400:latin', 'Halant::latin' ]
    }
  };

  (function() {
    var wf = document.createElement('script');
    wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
        '://ajax.googleapis.com/ajax/libs/webfont/1.5.0/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(wf, s);
  })();
</script>

</body>
</html>