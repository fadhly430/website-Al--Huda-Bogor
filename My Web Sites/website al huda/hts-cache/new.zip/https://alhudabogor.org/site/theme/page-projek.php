<!DOCTYPE html>
<html lang="id-ID" >
<head>
<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '261083737929935');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=261083737929935&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

  <title>Yayasan Islam Al Huda Bogor-Indonesia</title>

  <link rel="stylesheet" href="//fonts.googleapis.com/earlyaccess/droidarabicnaskh.css" type="text/css">
  <link rel="stylesheet" href="css/main.css" type="text/css">
  <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="vendor/flexslider/flexslider.css" type="text/css">

  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/main.js"></script>
  <script type="text/javascript" src="vendor/flexslider/jquery.flexslider-min.js"></script>
</head>
<body class="ltr">
<!-- Wrap all page content here -->
<div id="wrap">
  <div class="site-header">
    <div class="container">
     <ul class="lang-switch block-group">
        <li class="block -ar ">
          <a href="?lang=ar"><i class="icon"></i><span>العربية</span></a>
        </li>
        <li class="block -id -active">
          <a href="?lang=id-ID"><i class="icon"></i><span>INDONESIA</span></a>
        </li>
      </ul>
      

      <a class="home-link" href="index.php" title="Yayasan Islam Al Huda Bogor-Indonesia" rel="home">
        <img class="logo u-cb" src="img/logo.jpg" alt="">
      </a>

      <ul class="menu-toggles block-group u-tb u-tu">
        <li class="menu-toggle menu-toggle--donate block"><a href="" class="button" data-menu="donate">Donasi<i class="fa fa-caret-down"></i></a></li>
        <li class="menu-toggle menu-toggle--primary block"><a href="" class="button -alt" data-menu="primary">Menu<i class="fa fa-caret-down"></i></a></li>
      </ul>

      <ul class="menu menu--donate u-tb u-tu">
        <li><a href="#">Menu #1</a></li>
        <li><a href="#">Menu #1</a></li>
      </ul>

      <ul class="menu menu--primary u-tb u-tu">
        <li class="">
          <a href="index.php">Beranda</a>
        </li>
        <li class="">
          <a href="page-profil.php">Profil</a>
        </li>
        <li class="-active">
          <a href="page-projek.php">Projek</a>
        </li>
        <li><a href="page-proposal.php">Proposal</a></li>
        <li><a href="archive.php">Kegiatan</a></li>
        <li><a href="archive.php">Galeri</a></li>
        <li><a href="archive.php">Artikel</a></li>
      </ul>
    </div>
  </div> <!-- /.site-header -->

  <div class="site-content">
    <div class="container"><div class="container__inner">
<p class="breadcrumbs">
  <span prefix="v: http://rdf.data-vocabulary.org/#">
    <span typeof="v:Breadcrumb"><a href="index.php" rel="v:url" property="v:title">Beranda</a></span> » <span typeof="v:Breadcrumb"><span class="breadcrumb_last" property="v:title">Projek</span></span>
  </span>
</p>

<div class="single single--page">
  <h1 class="page__title">Projek</h1>

  <div class="page__content">
    <ul class="grid-thumbs block-group">
          <li class="grid-thumbs__item block -md-1-3 -sm-1-2">
        <div class="block-thumb">
          <a href="single.php" class="block-thumb__inner">
            <img src="placeholder/?r=320-200-projdet0" alt="" class="block-thumb__thumb">
          </a>
        </div>
      </li>
          <li class="grid-thumbs__item block -md-1-3 -sm-1-2">
        <div class="block-thumb">
          <a href="single.php" class="block-thumb__inner">
            <img src="placeholder/?r=320-200-projdet1" alt="" class="block-thumb__thumb">
          </a>
        </div>
      </li>
          <li class="grid-thumbs__item block -md-1-3 -sm-1-2">
        <div class="block-thumb">
          <a href="single.php" class="block-thumb__inner">
            <img src="placeholder/?r=320-200-projdet2" alt="" class="block-thumb__thumb">
          </a>
        </div>
      </li>
          <li class="grid-thumbs__item block -md-1-3 -sm-1-2">
        <div class="block-thumb">
          <a href="single.php" class="block-thumb__inner">
            <img src="placeholder/?r=320-200-projdet3" alt="" class="block-thumb__thumb">
          </a>
        </div>
      </li>
          <li class="grid-thumbs__item block -md-1-3 -sm-1-2">
        <div class="block-thumb">
          <a href="single.php" class="block-thumb__inner">
            <img src="placeholder/?r=320-200-projdet4" alt="" class="block-thumb__thumb">
          </a>
        </div>
      </li>
          <li class="grid-thumbs__item block -md-1-3 -sm-1-2">
        <div class="block-thumb">
          <a href="single.php" class="block-thumb__inner">
            <img src="placeholder/?r=320-200-projdet5" alt="" class="block-thumb__thumb">
          </a>
        </div>
      </li>
        </ul>
  </div>
</div>

    </div></div>
  </div> <!-- /.site-content -->

  <div class="site-footer">
    <div class="site-footer__top">
      <div class="container"><div class="container__inner">
        <div class="block-group">
          <p class="copyright block">Copyright &copy; 2019 Yayasan Islam Al Huda Bogor-Indonesia</p>

          <ul class="social-links block">
            <li><a href="http://www.facebook.com/" class="facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="http://twitter.com/" class="twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a href="feed" class="feed"><i class="fa fa-rss"></i></a></li>
          </ul>

        
        </div></div>
      </div>
    </div>

    <div class="site-footer__bottom">
      <div class="container">
        <div class="block-group">
          <div class="block -md-1-3">
            <h4 class="block__title">Tentang Kami</h4>

            <p>Yayasan Islam Al Huda Bogor-Indonesia adalah salah satu lembaga yang konsentrasi bergerak dalam Program Dakwah, Pendidikan, dan Sosial.</p>

            <p><a href="#" class="button">Selengkapnya</a></p>
          </div>
          <div class="block -sm-1-2 -md-1-3">
            <h4 class="block__title">Salurkan Donasi Anda</h4>

            <ul class="list-bullet-square">
              <li>Bank Syariah Mandiri (BSM) <br>
              No. Rekening: 1234.5678.90 <br>
              a/n Yayasan Islam Al Huda Bogor</li>
            </ul>

            <p><a href="#" class="button">Konfirmasi Donasi</a></p>
          </div>
          <div class="block -sm-1-2 -md-1-3">
            <h4 class="block__title">Kontak Kami</h4>

            <div class="vcard">
              <p class="org">Yayasan Islam Al Huda Bogor-Indonesia</p>
              <p class="adr">
                <span class="street-address">Jalan Raya Cimanglid Gg. Purnama RT/RW 05/01 PO. Box: 01 Ciomas</span>,
                <span class="locality">Bogor</span>,
                <span class="postal-code">16610</span>,
                <span class="region">Jawa Barat</span>,
                <span class="country-name">Indonesia</span>
              </p>
              <p class="tel">Telp. <span class="value">+62 251 487512</span></p>
              <p class="tel"><span class="type">Fax</span>. <span class="value">+62 251 487512</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> <!-- /#wrap -->

<script type="text/javascript">
  WebFontConfig = {
    google: {
      families: [ 'Roboto:900,900italic,400italic,700italic,700,400:latin', 'Halant::latin' ]
    }
  };

  (function() {
    var wf = document.createElement('script');
    wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
        '://ajax.googleapis.com/ajax/libs/webfont/1.5.0/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(wf, s);
  })();
</script>
</body>
</html>